/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Interfaces;

import Classes.Booking;
import Classes.ExcelReader;
import Classes.Record;
import Classes.State;
import EDD.Bst;
import EDD.HashTable;
import EDD.List;
import java.awt.Color;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Juan
 */
public class MainMenu extends javax.swing.JFrame {
    //Variables para poder manejar la ventana
    private int xMouse, yMouse;
    
    //Estructuras de datos
    private HashTable stateTable;
    private Bst bookingBst;
    private Bst recordBst;
    private HashTable roomTable;
        
    //Variables de la interfaz
    private javax.swing.JToggleButton[] buttons;
    private DefaultTableModel tableModel;
    
    
    
    public MainMenu() {
        initComponents(); 
        this.stateTable = ExcelReader.getState();  
        this.bookingBst = ExcelReader.getBookingBst();
        this.recordBst = ExcelReader.getRecordBst();
        this.roomTable = ExcelReader.getRoom();
        
        
        buttons = new javax.swing.JToggleButton[5];
        buttons[0] = searchClient;
        buttons[1] = searchBooking;
        buttons[2] = searchRecord;
        buttons[3] = checkIn;
        buttons[4] = checkOut;
        
        searchClientScreen.setVisible(false);
        searchBookingScreen.setVisible(false);
        searchRecordScreen.setVisible(false);
        checkInScreen.setVisible(false);
        checkOutScreen.setVisible(false);
        
        errorLabelSC.setText("");
        errorLabelSB.setText("");
        errorLabelSR.setText("");
        errorLabelCI.setText("");
        errorLabelCO.setText("");
        roomOutputCI.setText("");
        
        this.tableModel = new DefaultTableModel();
        setModel();
    }
    
    private void setModel(){
        String[] header = {"Cedula", "Nombre", "Apellido", "Email", "Genero", "Fecha llegada", "Nro habitacion"};
        tableModel.setColumnIdentifiers(header);
        recordsOutputSR.setModel(tableModel);
    }
    
    private void setData(){
        
    }
    
    public void handleToggle(){
        for(javax.swing.JToggleButton button: buttons){
            button.setContentAreaFilled(false);
            button.setOpaque(true);
            if(button.isSelected()){
                button.setBackground(new Color(81, 196, 81));
            }
            else{
                button.setBackground(new Color(153, 255, 153));
            }
        }
    }
    
    public void handleScreens(){
        searchClientScreen.setVisible(false);
        searchBookingScreen.setVisible(false);
        searchRecordScreen.setVisible(false);
        checkInScreen.setVisible(false);
        checkOutScreen.setVisible(false);
    }
    

          
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup2 = new javax.swing.ButtonGroup();
        background = new javax.swing.JPanel();
        header = new javax.swing.JPanel();
        close = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        leftContainer = new javax.swing.JPanel();
        checkOut = new javax.swing.JToggleButton();
        searchClient = new javax.swing.JToggleButton();
        searchBooking = new javax.swing.JToggleButton();
        searchRecord = new javax.swing.JToggleButton();
        checkIn = new javax.swing.JToggleButton();
        save = new javax.swing.JButton();
        rightContainer = new javax.swing.JPanel();
        searchClientScreen = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        searchClientScreen1 = new javax.swing.JPanel();
        inputLastNameSC = new javax.swing.JTextField();
        inputNameSC = new javax.swing.JTextField();
        nameLabelSC = new javax.swing.JLabel();
        searchSC = new javax.swing.JButton();
        lastNameLabelSC = new javax.swing.JLabel();
        numRoomLabelSC = new javax.swing.JLabel();
        emailLabelSC = new javax.swing.JLabel();
        genderLabelSC = new javax.swing.JLabel();
        phoneLabelSC = new javax.swing.JLabel();
        dateInLabelSC = new javax.swing.JLabel();
        errorLabelSC = new javax.swing.JLabel();
        searchBookingScreen = new javax.swing.JPanel();
        inputIdSB = new javax.swing.JTextField();
        nameLabelSB = new javax.swing.JLabel();
        searachSB = new javax.swing.JButton();
        lastNameLabelSB = new javax.swing.JLabel();
        idLabelSB = new javax.swing.JLabel();
        emailLabelSB = new javax.swing.JLabel();
        genderLabelSB = new javax.swing.JLabel();
        roomTypeLabelSB = new javax.swing.JLabel();
        phoneLabelSB = new javax.swing.JLabel();
        dateInLabelSB = new javax.swing.JLabel();
        dateOutLabelSB = new javax.swing.JLabel();
        errorLabelSB = new javax.swing.JLabel();
        searchRecordScreen = new javax.swing.JPanel();
        inputNumRoomSR = new javax.swing.JTextField();
        searchSR = new javax.swing.JButton();
        errorLabelSR = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        recordsOutputSR = new javax.swing.JTable();
        checkInScreen = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        inputIdCI = new javax.swing.JTextField();
        checkInCI = new javax.swing.JButton();
        errorLabelCI = new javax.swing.JLabel();
        roomOutputCI = new javax.swing.JLabel();
        checkOutScreen = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        inputLastNameCO = new javax.swing.JTextField();
        inputNameCO = new javax.swing.JTextField();
        checkoutCO = new javax.swing.JButton();
        errorLabelCO = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);
        setResizable(false);

        background.setBackground(new java.awt.Color(204, 204, 204));
        background.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        background.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        header.setBackground(new java.awt.Color(255, 255, 255));
        header.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 0, 1, new java.awt.Color(0, 0, 0)));
        header.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                headerMouseDragged(evt);
            }
        });
        header.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                headerMousePressed(evt);
            }
        });
        header.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        close.setBackground(new java.awt.Color(255, 0, 0));
        close.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        close.setForeground(new java.awt.Color(255, 255, 255));
        close.setText("X");
        close.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 0, 1, new java.awt.Color(0, 0, 0)));
        close.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeActionPerformed(evt);
            }
        });
        header.add(close, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 0, 40, 40));

        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("Hotel Booking");
        header.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, 20));

        background.add(header, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 40));

        leftContainer.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        checkOut.setBackground(new java.awt.Color(153, 255, 153));
        buttonGroup2.add(checkOut);
        checkOut.setText("Check-out");
        checkOut.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 1, 1, 0, new java.awt.Color(0, 0, 0)));
        checkOut.setOpaque(true);
        checkOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkOutActionPerformed(evt);
            }
        });
        leftContainer.add(checkOut, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 320, 200, 80));

        searchClient.setBackground(new java.awt.Color(153, 255, 153));
        buttonGroup2.add(searchClient);
        searchClient.setText("Buscar clientes hospedados");
        searchClient.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 0, new java.awt.Color(0, 0, 0)));
        searchClient.setOpaque(true);
        searchClient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchClientActionPerformed(evt);
            }
        });
        leftContainer.add(searchClient, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 200, 80));

        searchBooking.setBackground(new java.awt.Color(153, 255, 153));
        buttonGroup2.add(searchBooking);
        searchBooking.setText("Buscar reservacion");
        searchBooking.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 1, 1, 0, new java.awt.Color(0, 0, 0)));
        searchBooking.setOpaque(true);
        searchBooking.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBookingActionPerformed(evt);
            }
        });
        leftContainer.add(searchBooking, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 200, 80));

        searchRecord.setBackground(new java.awt.Color(153, 255, 153));
        buttonGroup2.add(searchRecord);
        searchRecord.setText("Ver historial de habitacion");
        searchRecord.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 1, 1, 0, new java.awt.Color(0, 0, 0)));
        searchRecord.setOpaque(true);
        searchRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchRecordActionPerformed(evt);
            }
        });
        leftContainer.add(searchRecord, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 200, 80));

        checkIn.setBackground(new java.awt.Color(153, 255, 153));
        buttonGroup2.add(checkIn);
        checkIn.setText("Check-in");
        checkIn.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 1, 1, 0, new java.awt.Color(0, 0, 0)));
        checkIn.setOpaque(true);
        checkIn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkInActionPerformed(evt);
            }
        });
        leftContainer.add(checkIn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 200, 80));

        save.setBackground(new java.awt.Color(249, 249, 249));
        save.setText("Guardar cambios");
        save.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 1, 2, 0, new java.awt.Color(0, 0, 0)));
        leftContainer.add(save, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 400, 200, 60));

        background.add(leftContainer, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 200, 460));

        rightContainer.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 2, 1, new java.awt.Color(0, 0, 0)));
        rightContainer.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        searchClientScreen.setBackground(new java.awt.Color(204, 204, 204));
        searchClientScreen.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 2, 1, new java.awt.Color(0, 0, 0)));
        searchClientScreen.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        searchClientScreen1.setBackground(new java.awt.Color(204, 204, 204));
        searchClientScreen1.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 2, 1, new java.awt.Color(0, 0, 0)));
        searchClientScreen1.setForeground(new java.awt.Color(255, 0, 51));
        searchClientScreen1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        inputLastNameSC.setBackground(new java.awt.Color(204, 204, 204));
        inputLastNameSC.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        inputLastNameSC.setForeground(new java.awt.Color(102, 102, 102));
        inputLastNameSC.setText("Ingrese apellido");
        inputLastNameSC.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        inputLastNameSC.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                inputLastNameSCFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                inputLastNameSCFocusLost(evt);
            }
        });
        inputLastNameSC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputLastNameSCActionPerformed(evt);
            }
        });
        searchClientScreen1.add(inputLastNameSC, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 90, 248, -1));

        inputNameSC.setBackground(new java.awt.Color(204, 204, 204));
        inputNameSC.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        inputNameSC.setForeground(new java.awt.Color(102, 102, 102));
        inputNameSC.setText("Ingrese nombre");
        inputNameSC.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        inputNameSC.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                inputNameSCFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                inputNameSCFocusLost(evt);
            }
        });
        inputNameSC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputNameSCActionPerformed(evt);
            }
        });
        searchClientScreen1.add(inputNameSC, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 40, 248, -1));

        nameLabelSC.setText("Nombre: ");
        searchClientScreen1.add(nameLabelSC, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 190, -1, -1));

        searchSC.setBackground(new java.awt.Color(102, 102, 102));
        searchSC.setForeground(new java.awt.Color(255, 255, 255));
        searchSC.setText("Buscar");
        searchSC.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        searchSC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchSCActionPerformed(evt);
            }
        });
        searchClientScreen1.add(searchSC, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 140, 100, -1));

        lastNameLabelSC.setText("Apellido: ");
        searchClientScreen1.add(lastNameLabelSC, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 220, -1, -1));

        numRoomLabelSC.setText("Numero de habitacion: ");
        searchClientScreen1.add(numRoomLabelSC, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, -1, -1));

        emailLabelSC.setText("Correo electronico: ");
        searchClientScreen1.add(emailLabelSC, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, -1, -1));

        genderLabelSC.setText("Genero: ");
        searchClientScreen1.add(genderLabelSC, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 310, -1, -1));

        phoneLabelSC.setText("Celular: ");
        searchClientScreen1.add(phoneLabelSC, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 340, -1, -1));

        dateInLabelSC.setText("Fecha de llegada: ");
        searchClientScreen1.add(dateInLabelSC, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 370, -1, -1));

        errorLabelSC.setForeground(new java.awt.Color(255, 0, 51));
        errorLabelSC.setText("Error Label");
        searchClientScreen1.add(errorLabelSC, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 140, -1, -1));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(searchClientScreen1, javax.swing.GroupLayout.PREFERRED_SIZE, 600, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(searchClientScreen1, javax.swing.GroupLayout.PREFERRED_SIZE, 460, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        searchClientScreen.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        rightContainer.add(searchClientScreen, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 460));

        searchBookingScreen.setBackground(new java.awt.Color(204, 204, 204));
        searchBookingScreen.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 2, 1, new java.awt.Color(0, 0, 0)));
        searchBookingScreen.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        inputIdSB.setBackground(new java.awt.Color(204, 204, 204));
        inputIdSB.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        inputIdSB.setForeground(new java.awt.Color(102, 102, 102));
        inputIdSB.setText("Ingrese cedula");
        inputIdSB.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        inputIdSB.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                inputIdSBFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                inputIdSBFocusLost(evt);
            }
        });
        searchBookingScreen.add(inputIdSB, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 280, -1));

        nameLabelSB.setText("Nombre:");
        searchBookingScreen.add(nameLabelSB, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, -1, -1));

        searachSB.setBackground(new java.awt.Color(102, 102, 102));
        searachSB.setForeground(new java.awt.Color(255, 255, 255));
        searachSB.setText("Buscar");
        searachSB.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        searachSB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searachSBActionPerformed(evt);
            }
        });
        searchBookingScreen.add(searachSB, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, 80, -1));

        lastNameLabelSB.setText("Apellido: ");
        searchBookingScreen.add(lastNameLabelSB, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 160, -1, -1));

        idLabelSB.setText("Cedula: ");
        searchBookingScreen.add(idLabelSB, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 190, -1, -1));

        emailLabelSB.setText("Correo: ");
        searchBookingScreen.add(emailLabelSB, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 220, -1, -1));

        genderLabelSB.setText("Genero: ");
        searchBookingScreen.add(genderLabelSB, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, -1, -1));

        roomTypeLabelSB.setText("Tipo de habitacion: ");
        searchBookingScreen.add(roomTypeLabelSB, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, -1, -1));

        phoneLabelSB.setText("Celular: ");
        searchBookingScreen.add(phoneLabelSB, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 310, -1, -1));

        dateInLabelSB.setText("Fecha de llegada: ");
        searchBookingScreen.add(dateInLabelSB, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 340, -1, -1));

        dateOutLabelSB.setText("Fecha de salida: ");
        searchBookingScreen.add(dateOutLabelSB, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 370, -1, -1));

        errorLabelSB.setForeground(new java.awt.Color(255, 0, 0));
        errorLabelSB.setText("Error Label");
        searchBookingScreen.add(errorLabelSB, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 70, -1, -1));

        rightContainer.add(searchBookingScreen, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 460));

        searchRecordScreen.setBackground(new java.awt.Color(204, 204, 204));
        searchRecordScreen.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 2, 1, new java.awt.Color(0, 0, 0)));
        searchRecordScreen.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        inputNumRoomSR.setBackground(new java.awt.Color(204, 204, 204));
        inputNumRoomSR.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        inputNumRoomSR.setForeground(new java.awt.Color(102, 102, 102));
        inputNumRoomSR.setText("Ingrese numero de habitacion");
        inputNumRoomSR.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        inputNumRoomSR.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                inputNumRoomSRFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                inputNumRoomSRFocusLost(evt);
            }
        });
        searchRecordScreen.add(inputNumRoomSR, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 300, -1));

        searchSR.setBackground(new java.awt.Color(102, 102, 102));
        searchSR.setForeground(new java.awt.Color(255, 255, 255));
        searchSR.setText("Buscar");
        searchSR.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        searchSR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchSRActionPerformed(evt);
            }
        });
        searchRecordScreen.add(searchSR, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, 100, -1));

        errorLabelSR.setForeground(new java.awt.Color(255, 0, 0));
        errorLabelSR.setText("Error Label");
        searchRecordScreen.add(errorLabelSR, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, -1, -1));

        recordsOutputSR.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(recordsOutputSR);

        searchRecordScreen.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 550, 210));

        rightContainer.add(searchRecordScreen, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 460));

        checkInScreen.setBackground(new java.awt.Color(204, 204, 204));
        checkInScreen.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 2, 1, new java.awt.Color(0, 0, 0)));
        checkInScreen.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel3.setText("Realizar Check-In");
        checkInScreen.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 100, -1, -1));

        inputIdCI.setBackground(new java.awt.Color(204, 204, 204));
        inputIdCI.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        inputIdCI.setForeground(new java.awt.Color(102, 102, 102));
        inputIdCI.setText("Ingrese cedula");
        inputIdCI.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        inputIdCI.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                inputIdCIFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                inputIdCIFocusLost(evt);
            }
        });
        checkInScreen.add(inputIdCI, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 190, 350, -1));

        checkInCI.setBackground(new java.awt.Color(102, 102, 102));
        checkInCI.setForeground(new java.awt.Color(255, 255, 255));
        checkInCI.setText("Check-in");
        checkInCI.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        checkInCI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkInCIActionPerformed(evt);
            }
        });
        checkInScreen.add(checkInCI, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 250, 110, -1));

        errorLabelCI.setForeground(new java.awt.Color(255, 0, 0));
        errorLabelCI.setText("Error Label");
        checkInScreen.add(errorLabelCI, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, -1, -1));

        roomOutputCI.setText("RoomOutput");
        checkInScreen.add(roomOutputCI, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 420, -1, -1));

        rightContainer.add(checkInScreen, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 460));

        checkOutScreen.setBackground(new java.awt.Color(204, 204, 204));
        checkOutScreen.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 2, 1, new java.awt.Color(0, 0, 0)));
        checkOutScreen.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel2.setText("Check-out");
        checkOutScreen.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 100, -1, -1));

        inputLastNameCO.setBackground(new java.awt.Color(204, 204, 204));
        inputLastNameCO.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        inputLastNameCO.setForeground(new java.awt.Color(102, 102, 102));
        inputLastNameCO.setText("Ingrese apellido");
        inputLastNameCO.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        inputLastNameCO.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                inputLastNameCOFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                inputLastNameCOFocusLost(evt);
            }
        });
        checkOutScreen.add(inputLastNameCO, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 210, 290, -1));

        inputNameCO.setBackground(new java.awt.Color(204, 204, 204));
        inputNameCO.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        inputNameCO.setForeground(new java.awt.Color(102, 102, 102));
        inputNameCO.setText("Ingrese nombre");
        inputNameCO.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        inputNameCO.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                inputNameCOFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                inputNameCOFocusLost(evt);
            }
        });
        checkOutScreen.add(inputNameCO, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 160, 290, -1));

        checkoutCO.setBackground(new java.awt.Color(102, 102, 102));
        checkoutCO.setForeground(new java.awt.Color(255, 255, 255));
        checkoutCO.setText("Check-out");
        checkoutCO.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        checkoutCO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkoutCOActionPerformed(evt);
            }
        });
        checkOutScreen.add(checkoutCO, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 270, 110, -1));

        errorLabelCO.setForeground(new java.awt.Color(255, 0, 0));
        errorLabelCO.setText("Error Label");
        checkOutScreen.add(errorLabelCO, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 370, -1, -1));

        rightContainer.add(checkOutScreen, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 460));

        background.add(rightContainer, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 40, 600, 460));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background, javax.swing.GroupLayout.PREFERRED_SIZE, 499, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void closeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeActionPerformed
        System.exit(0);
    }//GEN-LAST:event_closeActionPerformed

    private void headerMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_headerMousePressed

    private void headerMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_headerMouseDragged

    private void searchClientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchClientActionPerformed
        handleToggle();
        handleScreens();
        searchClientScreen.setVisible(true);
    }//GEN-LAST:event_searchClientActionPerformed

    private void searchBookingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBookingActionPerformed
        handleToggle();
        handleScreens();
        searchBookingScreen.setVisible(true);
    }//GEN-LAST:event_searchBookingActionPerformed

    private void searchRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchRecordActionPerformed
        handleToggle(); 
        handleScreens();
        searchRecordScreen.setVisible(true);
    }//GEN-LAST:event_searchRecordActionPerformed

    private void checkInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkInActionPerformed
        handleToggle();
        handleScreens();
        checkInScreen.setVisible(true);
    }//GEN-LAST:event_checkInActionPerformed

    private void checkOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkOutActionPerformed
        handleToggle();
        handleScreens();
        checkOutScreen.setVisible(true);
    }//GEN-LAST:event_checkOutActionPerformed

    private void inputLastNameSCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputLastNameSCActionPerformed
        
    }//GEN-LAST:event_inputLastNameSCActionPerformed

    private void inputNameSCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputNameSCActionPerformed
        
    }//GEN-LAST:event_inputNameSCActionPerformed

    private void searchSCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchSCActionPerformed
        errorLabelSC.setText("");
        nameLabelSC.setText("Nombre: ");
        lastNameLabelSC.setText("Apellido: ");
        numRoomLabelSC.setText("Numero de habitacion: ");
        emailLabelSC.setText("Correo electronico: ");
        genderLabelSC.setText("Genero: ");
        phoneLabelSC.setText("Celular: ");
        dateInLabelSC.setText("Fecha de llegada: ");
        
        String name = inputNameSC.getText();
        String lastName = inputLastNameSC.getText();
        
        if(name.isBlank() || lastName.isBlank()){
            errorLabelSC.setText("Error: ingrese todos los valores de los campos");
        }
        else if(name.equals("Ingrese nombre") || lastName.equals("Ingrese apellido")){
            errorLabelSC.setText("Error: ingrese todos los valores de los campos");
        }
        else{
            State state = stateTable.getState(name, lastName);
            if(state != null){
                nameLabelSC.setText(nameLabelSC.getText() + state.getName());
                lastNameLabelSC.setText(lastNameLabelSC.getText() + state.getLastName());                
                if(state.getNumRoom() == null)numRoomLabelSC.setText("Sin habitacion");
                else numRoomLabelSC.setText(numRoomLabelSC.getText() + state.getNumRoom());                
                emailLabelSC.setText(emailLabelSC.getText() + state.getEmail());
                genderLabelSC.setText(genderLabelSC.getText() + state.getGender());
                phoneLabelSC.setText(phoneLabelSC.getText() + state.getPhone());
                dateInLabelSC.setText(dateInLabelSC.getText() + state.getDateIn());                
            }
            else{
                errorLabelSC.setText("Error: cliente no encontrado");
            }            
        }
        inputNameSC.setForeground(new Color(102, 102, 102));
        inputNameSC.setText("Ingrese nombre");
        
        inputLastNameSC.setForeground(new Color(102, 102, 102));
        inputLastNameSC.setText("Ingrese apellido");
    }//GEN-LAST:event_searchSCActionPerformed

    private void inputNameSCFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_inputNameSCFocusGained
        if(inputNameSC.getText().equals("Ingrese nombre")){
            inputNameSC.setForeground(Color.black);
            inputNameSC.setText("");
        }
    }//GEN-LAST:event_inputNameSCFocusGained

    private void inputNameSCFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_inputNameSCFocusLost
        if(inputNameSC.getText().isBlank()){
            inputNameSC.setForeground(new Color(102, 102, 102));
            inputNameSC.setText("Ingrese nombre");
        }
    }//GEN-LAST:event_inputNameSCFocusLost

    private void inputLastNameSCFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_inputLastNameSCFocusGained
        if(inputLastNameSC.getText().equals("Ingrese apellido")){
            inputLastNameSC.setForeground(Color.black);
            inputLastNameSC.setText("");
        }
    }//GEN-LAST:event_inputLastNameSCFocusGained

    private void inputLastNameSCFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_inputLastNameSCFocusLost
        if(inputLastNameSC.getText().isBlank()){
            inputLastNameSC.setForeground(new Color(102, 102, 102));
            inputLastNameSC.setText("Ingrese apellido");
        }
    }//GEN-LAST:event_inputLastNameSCFocusLost

    private void inputIdSBFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_inputIdSBFocusGained
        if(inputIdSB.getText().equals("Ingrese cedula")){
            inputIdSB.setText("");
        }
    }//GEN-LAST:event_inputIdSBFocusGained

    private void inputIdSBFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_inputIdSBFocusLost
        if(inputIdSB.getText().isBlank()){
            inputIdSB.setText("Ingrese cedula");
        }
    }//GEN-LAST:event_inputIdSBFocusLost

    private void searachSBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searachSBActionPerformed
        errorLabelSB.setText("");
        nameLabelSB.setText("Nombre: ");
        lastNameLabelSB.setText("Apellido: ");
        idLabelSB.setText("Cedula: ");
        emailLabelSB.setText("Correo: ");
        genderLabelSB.setText("Genero: ");
        roomTypeLabelSB.setText("Tipo de habitacion: ");
        phoneLabelSB.setText("Celular: ");
        dateInLabelSB.setText("Fecha de llegada: ");
        dateOutLabelSB.setText("Fecha de salida: ");
        
        String id = inputIdSB.getText();
        
        if(id.equals("Ingrese cedula") || id.isBlank()){
            errorLabelSB.setText("Error: ingrese todos los valores de los campos");
        }
        else{
            Booking booking = this.bookingBst.getBooking(bookingBst.getRoot(), id);
            if(booking != null){
                
                nameLabelSB.setText(nameLabelSB.getText() + booking.getName());
                lastNameLabelSB.setText(lastNameLabelSB.getText() + booking.getLastName());
                idLabelSB.setText(idLabelSB.getText() + booking.getId());
                emailLabelSB.setText(emailLabelSB.getText() + booking.getEmail());
                genderLabelSB.setText(genderLabelSB.getText() + booking.getGender());
                roomTypeLabelSB.setText(roomTypeLabelSB.getText() + booking.getRoomType());
                phoneLabelSB.setText(phoneLabelSB.getText() + booking.getPhone());
                dateInLabelSB.setText(dateInLabelSB.getText() + booking.getDateIn());
                dateOutLabelSB.setText(dateOutLabelSB.getText() + booking.getDateOut());                                
            }
            else{
                errorLabelSB.setText("Error: no se encontro la reservacion");
            }
        }
        
        inputIdSB.setText("Ingrese cedula");
        
    }//GEN-LAST:event_searachSBActionPerformed

    private void searchSRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchSRActionPerformed
        errorLabelSR.setText("");
        
        int rowCount = tableModel.getRowCount();
                
        for (int i = rowCount - 1; i >= 0; i--) {
            tableModel.removeRow(i);
        }
        
        String numRoom = inputNumRoomSR.getText();
        
        if(numRoom.equals("Ingrese numero de habitacion") || numRoom.isBlank()){
            errorLabelSR.setText("Error: ingrese todos los valores de los campos");
        }
        else{
            List records = new List();
            this.recordBst.getRecords(this.recordBst.getRoot(), numRoom, records);
            
            Object[] array = new Object[tableModel.getColumnCount()];
            for (int i = 0; i < records.len(); i++) {
                Record auxRecord = (Record) records.get(i);
                array[0] = auxRecord.getId();
                array[1] = auxRecord.getName();
                array[2] = auxRecord.getLastName();
                array[3] = auxRecord.getEmail();
                array[4] = auxRecord.getGender();
                array[5] = auxRecord.getDateIn();
                array[6] = auxRecord.getNumRoom();
                tableModel.addRow(array);                        
            }
            recordsOutputSR.setModel(tableModel);
        }
    }//GEN-LAST:event_searchSRActionPerformed

    private void inputNumRoomSRFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_inputNumRoomSRFocusGained
        if(inputNumRoomSR.getText().equals("Ingrese numero de habitacion")){
            inputNumRoomSR.setForeground(Color.black);
            inputNumRoomSR.setText("");
        }
    }//GEN-LAST:event_inputNumRoomSRFocusGained

    private void inputNumRoomSRFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_inputNumRoomSRFocusLost
        if(inputNumRoomSR.getText().isBlank()){
            inputNumRoomSR.setForeground(new Color(102, 102, 102));
            inputNumRoomSR.setText("Ingrese numero de habitacion");
        }
    }//GEN-LAST:event_inputNumRoomSRFocusLost

    private void inputIdCIFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_inputIdCIFocusGained
        if(inputIdCI.getText().equals("Ingrese cedula")){
            inputIdCI.setForeground(Color.black);
            inputIdCI.setText("");
        }
    }//GEN-LAST:event_inputIdCIFocusGained

    private void inputIdCIFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_inputIdCIFocusLost
        if(inputIdCI.getText().isBlank()){
            inputIdCI.setForeground(new Color(102, 102, 102));
            inputIdCI.setText("Ingrese cedula");
        }
    }//GEN-LAST:event_inputIdCIFocusLost

    private void checkInCIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkInCIActionPerformed
        errorLabelCI.setForeground(Color.red);
        errorLabelCI.setText("");
        String id = inputIdCI.getText();
        
        if(id.equals("Ingrese cedula") || id.isBlank()){
            errorLabelCI.setText("Error: ingrese todos los campos del formulario");
        }
        else{
            Booking booking = bookingBst.getBooking(bookingBst.getRoot(), id);
            bookingBst.removeBooking(bookingBst.getRoot(), id);
            
            //Lista de habitaciones ocupadas
            List rooms = stateTable.getRooms();         
            
            String numRoom = "";
            for (int i = 0; i < rooms.len(); i++) {
                String aux = (String) rooms.get(i);
                                
                if(roomTable.getRoom(aux).getTypeRoom().equals(booking.getRoomType())){
                    numRoom = aux;
                }
            }
            
            String phone = booking.getPhone();
            String name = booking.getName();
            String lastName = booking.getLastName();
            String email = booking.getEmail();
            String gender = booking.getGender();
            String dateIn = booking.getDateIn();
            
            State newState = new State(numRoom, phone, name, lastName, email, gender, dateIn);
            stateTable.insert(newState);
            
            errorLabelCI.setForeground(new Color(0, 153, 51));
            errorLabelCI.setText("Se ha realizado el check-in con exito!");
            roomOutputCI.setText("Numero de habitacion: " + numRoom);
            
            
            
        }
        
        
    }//GEN-LAST:event_checkInCIActionPerformed

    private void inputNameCOFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_inputNameCOFocusGained
        if(inputNameCO.getText().equals("Ingrese nombre")){
            inputNameCO.setForeground(Color.black);
            inputNameCO.setText("");
        }
    }//GEN-LAST:event_inputNameCOFocusGained

    private void inputNameCOFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_inputNameCOFocusLost
        if(inputNameCO.getText().isBlank()){
            inputNameCO.setForeground(new Color(102, 102, 102));
            inputNameCO.setText("Ingrese nombre");
        }
    }//GEN-LAST:event_inputNameCOFocusLost

    private void inputLastNameCOFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_inputLastNameCOFocusGained
        if(inputLastNameCO.getText().equals("Ingrese apellido")){
            inputLastNameCO.setForeground(Color.black);
            inputLastNameCO.setText("");
        }
    }//GEN-LAST:event_inputLastNameCOFocusGained

    private void inputLastNameCOFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_inputLastNameCOFocusLost
        if(inputLastNameCO.getText().isBlank()){
            inputLastNameCO.setForeground(new Color(102, 102, 102));
            inputLastNameCO.setText("Ingrese apellido");
        }
    }//GEN-LAST:event_inputLastNameCOFocusLost

    private void checkoutCOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkoutCOActionPerformed
        errorLabelCO.setForeground(Color.red);
        errorLabelCO.setText("");
        String name = inputNameCO.getText();
        String lastName = inputLastNameCO.getText();
        
        if(name.isBlank() || lastName.isBlank()){
            errorLabelCO.setText("Error: ingrese todos los campos del formulario");
        }
        else if(name.equals("Ingrese nombre") || lastName.equals("Ingrese apellido")){
            errorLabelCO.setText("Error: ingrese todos los campos del formulario");
        }
        else{
            System.out.println(name + lastName);
            State state = stateTable.getState(name, lastName);
            System.out.println(state);
            stateTable.removeState(name, lastName);
            
            String id = "";
            String email = state.getEmail();
            String gender = state.getGender();
            String dateIn = state.getDateIn();
            String numRoom = state.getNumRoom();
            
            Record newRecord = new Record(name, lastName, email, gender, dateIn, id, numRoom);
            recordBst.insertRecord(recordBst.getRoot(), newRecord);
            
            errorLabelCO.setForeground(new Color(0, 153, 51));
            errorLabelCO.setText("Check-out realizado con exito!");            
            
        }
    }//GEN-LAST:event_checkoutCOActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel background;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JToggleButton checkIn;
    private javax.swing.JButton checkInCI;
    private javax.swing.JPanel checkInScreen;
    private javax.swing.JToggleButton checkOut;
    private javax.swing.JPanel checkOutScreen;
    private javax.swing.JButton checkoutCO;
    private javax.swing.JButton close;
    private javax.swing.JLabel dateInLabelSB;
    private javax.swing.JLabel dateInLabelSC;
    private javax.swing.JLabel dateOutLabelSB;
    private javax.swing.JLabel emailLabelSB;
    private javax.swing.JLabel emailLabelSC;
    private javax.swing.JLabel errorLabelCI;
    private javax.swing.JLabel errorLabelCO;
    private javax.swing.JLabel errorLabelSB;
    private javax.swing.JLabel errorLabelSC;
    private javax.swing.JLabel errorLabelSR;
    private javax.swing.JLabel genderLabelSB;
    private javax.swing.JLabel genderLabelSC;
    private javax.swing.JPanel header;
    private javax.swing.JLabel idLabelSB;
    private javax.swing.JTextField inputIdCI;
    private javax.swing.JTextField inputIdSB;
    private javax.swing.JTextField inputLastNameCO;
    private javax.swing.JTextField inputLastNameSC;
    private javax.swing.JTextField inputNameCO;
    private javax.swing.JTextField inputNameSC;
    private javax.swing.JTextField inputNumRoomSR;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lastNameLabelSB;
    private javax.swing.JLabel lastNameLabelSC;
    private javax.swing.JPanel leftContainer;
    private javax.swing.JLabel nameLabelSB;
    private javax.swing.JLabel nameLabelSC;
    private javax.swing.JLabel numRoomLabelSC;
    private javax.swing.JLabel phoneLabelSB;
    private javax.swing.JLabel phoneLabelSC;
    private javax.swing.JTable recordsOutputSR;
    private javax.swing.JPanel rightContainer;
    private javax.swing.JLabel roomOutputCI;
    private javax.swing.JLabel roomTypeLabelSB;
    private javax.swing.JButton save;
    private javax.swing.JButton searachSB;
    private javax.swing.JToggleButton searchBooking;
    private javax.swing.JPanel searchBookingScreen;
    private javax.swing.JToggleButton searchClient;
    private javax.swing.JPanel searchClientScreen;
    private javax.swing.JPanel searchClientScreen1;
    private javax.swing.JToggleButton searchRecord;
    private javax.swing.JPanel searchRecordScreen;
    private javax.swing.JButton searchSC;
    private javax.swing.JButton searchSR;
    // End of variables declaration//GEN-END:variables
}
