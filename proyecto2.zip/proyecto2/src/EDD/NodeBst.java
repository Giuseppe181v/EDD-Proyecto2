/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EDD;

/**
 *
 * @author Juan
 */
public class NodeBst<T> {
    private NodeBst left;
    private NodeBst right;
    private T data;

    public NodeBst(T data) {
        this.left = null;
        this.right = null;
        this.data = data;
    }   

    public NodeBst getLeft() {
        return left;
    }

    public void setLeft(NodeBst left) {
        this.left = left;
    }

    public NodeBst getRight() {
        return right;
    }

    public void setRight(NodeBst right) {
        this.right = right;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
    
    
    
    
}
