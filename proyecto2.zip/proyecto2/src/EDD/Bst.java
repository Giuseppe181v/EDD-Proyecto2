/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EDD;

import Classes.Booking;
import Classes.Record;

/**
 *
 * @author Juan
 */
public class Bst {
    private NodeBst root;

    public Bst(NodeBst root) {
        this.root = root;
    }
    
    public Bst() {
        this.root = null;
    }

    public NodeBst getRoot() {
        return root;
    }

    public void setRoot(NodeBst root) {
        this.root = root;
    }
    
    public long uniqueData(Booking booking){
        String id = booking.getId();
        String dateIn = booking.getDateIn();
        dateIn = dateIn.replace("/", "");
        
        String code = id + dateIn;
        return Long.parseLong(code);
    }
    
    public long uniqueData(Record record){
        String id = record.getId();
        String dateIn = record.getDateIn();
        dateIn = dateIn.replace("/", "");
        
        String code = id + dateIn;
        return Long.parseLong(code);
    }
    
    
    
    public void insertBooking(NodeBst current, Booking booking){        
        if(this.root == null){
            this.root = new NodeBst(booking);
        }
        else{            
            Booking currentBooking = (Booking) current.getData();

            int id = Integer.parseInt(booking.getId());
            int currentId = Integer.parseInt(currentBooking.getId());

            if(id < currentId){
                if(current.getLeft() != null){
                    insertBooking(current.getLeft(), booking);                        
                }
                else{
                    current.setLeft(new NodeBst(booking));
                }
            }
            else if(id > currentId){
                if(current.getRight() != null){
                    insertBooking(current.getRight(), booking);                        
                }
                else{
                    current.setRight(new NodeBst(booking));
                }
            }
            else{
                System.out.println("La reserva ya existe");
            }            
        }                        
    }
    
    
    
    
    public void insertRecord(NodeBst current, Record record){
        if(this.root == null){
            this.root = new NodeBst(record);
        }
        else{            
            Record currentRecord = (Record) current.getData();

            long recordCode = uniqueData(record);
            long currentCode = uniqueData(currentRecord);

            if(recordCode < currentCode){
                if(current.getLeft() != null){
                    insertRecord(current.getLeft(), record);                        
                }
                else{
                    current.setLeft(new NodeBst(record));
                }
            }
            else if(recordCode > currentCode){
                if(current.getRight() != null){
                    insertRecord(current.getRight(), record);                        
                }
                else{
                    current.setRight(new NodeBst(record));
                }
            }
            else{
                System.out.println("La reserva ya existe");
            }            
        }
    }
    
    
                
    public Booking getBooking(NodeBst current, String id){        
          Booking booking = null;
          if(current != null){
              Booking currentBooking = (Booking) current.getData();
              
              int idInt = Integer.parseInt(id);
              int currentId = Integer.parseInt(currentBooking.getId());
              
              if(idInt < currentId){
                  booking = getBooking(current.getLeft(), id);
              }
              else if(idInt > currentId){
                  booking = getBooking(current.getRight(), id);
              }
              else if(idInt == currentId){
                  return currentBooking;
              }              
          }        
          return booking;        
    }
    
    
    public void getRecords(NodeBst current, String numRoom, List records){
        if(current != null){
            getRecords(current.getLeft(), numRoom, records);
            
            Record currentRecord = (Record) current.getData();
            if(currentRecord.getNumRoom().equals(numRoom)){
                records.append(currentRecord);
            }
            
            getRecords(current.getRight(), numRoom, records);
        }
    }
    
    public void add(NodeBst current, int num){
        if(root == null){
            root = new NodeBst(num);
        }
        else{
            int data = (int) current.getData();
            if(num < data){
                if(current.getLeft() == null){
                    current.setLeft(new NodeBst(num));
                }
                else{
                    add(current.getLeft(), num);                    
                }
            }
            else if(num > data){
                if(current.getRight() == null){
                    current.setRight(new NodeBst(num));
                }
                else{
                    add(current.getRight(), num);                    
                }
            }
            else{
                System.out.println("No se pueden agregar elemetos repetidos");
            }            
        }
    }
    
    public void removeBooking(NodeBst<Booking> current, String id){
        try{
            
            Booking bookingRoot = (Booking) root.getData();
            if(root == null){ //Si el arbol esta vacio
                System.out.println("Arbol vacio");
            }
            else if(bookingRoot.getId().equals(id)){
                //Obtengo el sucesor del dato a eliminar
                NodeBst<Booking> sucesorData = getSucesor(root, Integer.parseInt(bookingRoot.getId()));

                //Lo elimino del arbol
                removeBooking(root, sucesorData.getData().getId());

                //Le digo al hijo izquierdo que su dato sea del sucesor
                root.setData(sucesorData.getData());
            }
            else{ //Si el arbol no esta vacio

                //Obtengo el dato del nodo actual
                int currentId = Integer.parseInt(current.getData().getId());
                int idInt = Integer.parseInt(id);            

                //si el numero es menor al dato del nodo actual
                if(idInt < currentId){

                    //si el hijo izquierdo del nodo actual es distinto de null
                    if(current.getLeft() != null){

                        //Obtengo hijo izquierdo y su dato
                        NodeBst<Booking> nodeLeft = current.getLeft();
                        int leftData = Integer.parseInt(nodeLeft.getData().getId());

                        //Si el dato del hijo izquierdo es igual al dato que busco eliminar
                        if(leftData == idInt){

                            //Si el hijo izquierdo no tiene hijos
                            if(nodeLeft.getLeft() == null && nodeLeft.getRight() == null){
                                current.setLeft(null);
                            }

                            //Si el hijo izquierdo tiene un hijo 
                            else if(nodeLeft.getLeft() != null && nodeLeft.getRight() == null){
                                current.setLeft(nodeLeft.getLeft());
                            }
                            else if(nodeLeft.getLeft() == null && nodeLeft.getRight() != null){
                                current.setLeft(nodeLeft.getRight());
                            }

                            //Si el hijo izquierdo tiene dos hijos
                            else if(nodeLeft.getLeft() != null && nodeLeft.getRight() != null){

                                //Obtengo el sucesor del dato a eliminar
                                NodeBst<Booking> sucesorData = getSucesor(root, leftData);

                                //Lo elimino del arbol
                                removeBooking(root, sucesorData.getData().getId());

                                //Le digo al hijo izquierdo que su dato sea del sucesor
                                nodeLeft.setData(sucesorData.getData());                            
                            }
                        }
                        //Si el dato del hijo izquierdo no es igual al numero
                        else{

                            //paso al hijo izquierdo
                            removeBooking(current.getLeft(), id);
                        }
                    }   
                }

                //Si numero es mayor al dato del nodo actual
                else if(idInt > currentId){

                    //Si el hijo derecho del nodp actual es distinto de null
                    if(current.getRight() != null){

                        //Obtengo hijo derecho y su dato
                        NodeBst<Booking> nodeRight = current.getRight();
                        int rightData = Integer.parseInt(nodeRight.getData().getId());

                        //Si el dato del hijo derecho es igual al dato que busco eliminar
                        if(rightData == idInt){

                            //Si el hijo derecho no tiene hijos
                            if(nodeRight.getLeft() == null && nodeRight.getRight() == null){
                                current.setRight(null);
                            }

                            //Si el hijo derecho tiene un hijo 
                            else if(nodeRight.getLeft() != null && nodeRight.getRight() == null){
                                current.setRight(nodeRight.getLeft());
                            }
                            else if(nodeRight.getLeft() == null && nodeRight.getRight() != null){
                                current.setRight(nodeRight.getRight());
                            }

                            //Si el hijo derecho tiene dos hijos
                            else if(nodeRight.getLeft() != null && nodeRight.getRight() != null){

                                //Obtengo el sucesor del dato a eliminar
                                NodeBst<Booking> sucesorData = getSucesor(root, rightData);

                                //Lo elimino del arbol
                                removeBooking(root, sucesorData.getData().getId());

                                //Le digo al hijo derecho que su dato sea del sucesor
                                nodeRight.setData(sucesorData.getData());                            
                            }
                        }
                        //Si el dato del hijo derecho no es igual al numero
                        else{

                            //paso al hijo derecho
                            removeBooking(current.getRight(), id);
                        }

                    }
                }else{

                }

            }
        }
        catch(Exception e){
            System.out.println("Error: booking no encontrado");
        }
    }
    
    public NodeBst getSucesor(NodeBst<Booking> current, int num) {
        if (current == null) {
            return null; 
        }

        NodeBst sucesor = null;

        if (Integer.parseInt(current.getData().getId()) <= num) {
            sucesor = getSucesor(current.getRight(), num);
        } 
        else {
            sucesor = getSucesor(current.getLeft(), num);
            if (sucesor == null) {
                sucesor = current;
            }
        }
        return sucesor;
    }

    
    
    
    public void inorder(NodeBst current){
        if(current != null){
            inorder(current.getLeft());            
            System.out.println(current + ", ");
            inorder(current.getRight());
        }
    }
    
    
}
