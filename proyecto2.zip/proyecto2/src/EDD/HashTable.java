/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EDD;

import Classes.Booking;
import Classes.Record;
import Classes.Room;
import Classes.State;

/**
 *
 * @author Juan
 */
public class HashTable<T> {
    //========/ Atributos de la clase /===========
    private List[] table;    
    
    
    
    //=========/ Constructor /=========
    public HashTable(int size) {
        this.table = new List[size];        
    }

    
    
    //==============/ Metodos de la clase /==============
    /**
     * Obtiene el valor del array de listas
     * @return 
     */
    public List[] getTable() {
        return table;
    }

    
    
    /**
     * Cambia el valor del array de listas
     * @param table 
     */
    public void setTable(List[] table) {
        this.table = table;
    }
    
    /**
     * Obtiene la capacidad del hashTable
     * @return 
     */
    public int getSize() {
        return table.length;
    }
    
    
    
    /**
     * Funcion hash para numeros enteros
     * @param num
     * @return indice en la tabla hash
     */
    public int hash(String num){        
        int value = 0;
        
        for (int i = 0; i < num.length(); i++) {            
            char digitChar = num.charAt(i);
            int digit = Character.getNumericValue(digitChar);
            
            value += digit;
        }
        
        return value % getSize();
    }
    
    
    
    /**
     * Funcion hash para nombre y apellido
     * @param num
     * @return indice en la tabla hash
     */
    public int hash(String name, String lastName){
        int value = 0;
        
        for (int i = 0; i < name.length(); i++) {
            value += name.charAt(i);
        }
        
        for (int i = 0; i < lastName.length(); i++) {
            value += lastName.charAt(i);
        }
        
        return value % getSize();
    }    
    
    
    
    /**
     * Insertar un registro de Estado en la tabla
     * @param state 
     */
    public void insert(State state){
        int index = hash(state.getName(), state.getLastName());
        
        if(this.table[index] == null){
            this.table[index] = new List(state);
        }
        else{
            this.table[index].append(state);
        }
    }
    
    
    
    /**
     * Insertar un registro de reservas en la tabla 
     * @param booking
     */
    public void insert(Booking booking){
        int index = hash(booking.getId());
        
        if(this.table[index] == null){
            this.table[index] = new List(booking);
        }
        else{
            this.table[index].append(booking);
        }
    }
    
    
    
    /**
     * Insertar un registro de habitacion en la tabla
     * @param room 
     */
    public void insert(Room room){
        double indexDouble = Double.parseDouble(room.getNumRoom());
        int index = (int) indexDouble;
        
        if(this.table[index] == null){
            this.table[index] = new List(room);
        }
        else{
            this.table[index].append(room);
        }
    }
    
    
    /**
     * Insertar un registro de habitacion en la tabla
     * @param record 
     */
    public void insert(Record record){
        int index = hash(record.getId());
        
        if(this.table[index] == null){
            this.table[index] = new List(record);
        }
        else{
               this.table[index].append(record);
        }
    }
    
    
    
    /**
     * Obtiene un estado del hashTable dado el nombre y el apellido
     * @param name
     * @param lastName
     * @return 
     */
    public State getState(String name, String lastName){
        int index = hash(name, lastName);
        
        List bucket = this.table[index];
        if(bucket != null){
            if(bucket.len() == 1){
                State auxState = (State) bucket.get(0);
                if(auxState.getName().equals(name) && auxState.getLastName().equals(lastName)){
                    return (State) bucket.get(0);                    
                }
            }
            else if(bucket.len() > 1){
                for (int i = 0; i < bucket.len(); i++) {
                    State auxState = (State) bucket.get(i);
                    String auxName = auxState.getName();
                    String auxLastName = auxState.getLastName();
                    
                    if(auxName.equals(name) && auxLastName.equals(lastName)){                        
                        return auxState;
                    }
                }
            }
        }
        return null;
    }
    
    
    
    /**
     * Obtiene una reservacion del hashTable dado el id
     * @param id
     * @return 
     */
    public Booking getBooking(String id){
        int index = hash(id);
        
        List bucket = this.table[index];
        if(bucket != null){
            if(bucket.len() == 1){
                return  (Booking) bucket.get(0);
            }
            else if(bucket.len() > 1){
                for (int i = 0; i < bucket.len(); i++) {
                    Booking auxBooking = (Booking) bucket.get(i);
                    String auxId = auxBooking.getId();
                    
                    if(auxId.equals(id)){
                        return auxBooking;
                    }
                }
            }
        }
        return null;
    }
    
    
    /**
     * Obtiene una habitacion del hashTable dado el numero de habitacion
     * @param numRoom
     * @return 
     */
    public Room getRoom(String numRoom){
        System.out.println(numRoom);
        int index = Integer.parseInt(numRoom);
        
        List bucket = this.table[index];
        if(bucket != null){
            if(bucket.len() == 1){
                return (Room) bucket.get(0);
            }
            else if(bucket.len() > 1){
                for (int i = 0; i < bucket.len(); i++) {
                    Room auxRoom = (Room) bucket.get(i);
                    String auxNumRoom = auxRoom.getNumRoom();
                    
                    if(auxNumRoom.equals(numRoom)){
                        return auxRoom;
                    }
                }
            }
        }
        return null;
    }
    
    
    /**
     * Obtiene un historico del hashTable dado el id
     * @param id
     * @return 
     */
    public Record getRecord(String id){
        int index = hash(id);
        
        List bucket = this.table[index];
        if(bucket != null){
            if(bucket.len() == 1){
                return (Record) bucket.get(0);
            }
            else if(bucket.len() > 1){
                for (int i = 0; i < bucket.len(); i++) {
                    Record auxRecord = (Record) bucket.get(i);
                    String auxId = auxRecord.getId();
                    
                    if(auxId.equals(id)){
                        return auxRecord;
                    }
                }
            }
        }
        return null;
    }
    
    
    public void removeState(String name, String lastName){
        int index = hash(name, lastName);
        
        List bucket = this.table[index];
        if(bucket == null){
            System.out.println("Elemento no existente");
        }
        else{
            if(bucket.len() == 1){
                bucket.pop(0);
            }
            else{
                for (int i = 0; i < bucket.len(); i++) {
                    State aux = (State) bucket.get(i);
                    
                    if(aux.getName().equals(name) && aux.getLastName().equals(lastName)){
                        bucket.pop(i);
                        break;
                    }
                }
            }
        }
    }
   
    
    public List<Integer> getRooms(){
        List roomsAvaible = new List();
        
        for(List list: table){
            if(list != null){
                if(!list.isEmpty()){
                    for (int i = 0; i < list.getSize(); i++) {
                        State auxState = (State) list.get(i);
                        if(auxState.getNumRoom() != null){
                            roomsAvaible.append(auxState.getNumRoom());                                            
                        }
                    }                
                }                
            }
        }
        
        return roomsAvaible;
    }
    
    
  
    

    
    
}
