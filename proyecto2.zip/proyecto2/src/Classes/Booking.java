/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author Juan
 */
public class Booking extends Client{
    private String id;
    private String roomType;
    private String phone;
    private String dateOut;

    public Booking(String id, String roomType, String phone, String dateOut, String name, String lastName, String email, String gender, String dateIn) {
        super(name, lastName, email, gender, dateIn);
        this.id = id;
        this.roomType = roomType;
        this.phone = phone;
        this.dateOut = dateOut;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }    

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDateOut() {
        return dateOut;
    }

    public void setDateOut(String dateOut) {
        this.dateOut = dateOut;
    }


    
    
    
    
    
    
}
