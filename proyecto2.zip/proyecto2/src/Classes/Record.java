/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author Juan
 */
public class Record extends Client{
    private String id;
    private String numRoom;

    public Record(String name, String lastName, String email, String gender, String dateIn, String id, String numRoom) {
        super(name, lastName, email, gender, dateIn);
        this.id = id;
        this.numRoom = numRoom;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNumRoom() {
        return numRoom;
    }

    public void setNumRoom(String numRoom) {
        this.numRoom = numRoom;
    }

    
    
    
}
