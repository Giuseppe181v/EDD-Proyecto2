/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author Juan
 */
public class State extends Client {
    private String numRoom;
    private String phone;

    public State(String numRoom, String phone, String name, String lastName, String email, String gender, String dateIn) {
        super(name, lastName, email, gender, dateIn);
        this.numRoom = numRoom;
        this.phone = phone;
    }

    public String getNumRoom() {
        return numRoom;
    }

    public void setNumRoom(String numRoom) {
        this.numRoom = numRoom;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    
    
}
