/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

import EDD.Bst;
import EDD.HashTable;
import EDD.List;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JFileChooser;
import org.apache.poi.ss.usermodel.Cell;
import static org.apache.poi.ss.usermodel.CellType.BLANK;
import static org.apache.poi.ss.usermodel.CellType.BOOLEAN;
import static org.apache.poi.ss.usermodel.CellType.FORMULA;
import static org.apache.poi.ss.usermodel.CellType.NUMERIC;
import static org.apache.poi.ss.usermodel.CellType.STRING;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author Juan
 * @param <T>
 */
public class ExcelReader<T> {
    //=========/ Constantes /==========
    private final static int BOOKING = 0;
    private final static int ROOM = 1;
    private final static int STATE = 2;
    private final static int RECORD = 3;
    
    //============/ Metodos de la clase /==========
    
    /**
     * Obtiene la hoja del excel dado su indice
     * @param sheetNum
     * @return 
     */
    public static Sheet getExcelSheet(int sheetNum){
        try{
            FileInputStream fileInput = new FileInputStream("Booking_hotel.xlsx");                         
            Workbook workbook = WorkbookFactory.create(fileInput);                        
            return workbook.getSheetAt(sheetNum);
        }
        catch(Exception e){
            System.out.println(e);
        }
        return null;
    }
    
    
    /**
     * Obtiene el valor de la celda
     * @param cell
     * @return 
     */
    public static String getCellValue(Cell cell){
        switch(cell.getCellTypeEnum()){
            case STRING:
                return cell.getStringCellValue();
                
            case NUMERIC:                
                if (DateUtil.isCellDateFormatted(cell)) {
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    return sdf.format(cell.getDateCellValue());                    
                } else {      
                    double cellDouble = cell.getNumericCellValue();                                        
                    return String.format("%.0f", cellDouble);
                }     
                
            case FORMULA:
                if (DateUtil.isCellDateFormatted(cell)) {
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    return sdf.format(cell.getDateCellValue());                    
                } else {                    
                    DataFormatter dataFormatter = new DataFormatter();
                    return dataFormatter.formatCellValue(cell);
                }
        }
        return null;
    }
    
    
    /**
     * Obtiene un hashTable con los datos de la hoja de estados
     * @return 
     */
    public static HashTable getState(){
        HashTable stateTable = new HashTable(500);
        
        Sheet sheet = getExcelSheet(STATE);        
        
        for(Row row: sheet){
            String[] rowValues = new String[7];
            
            for(Cell cell: row){
                if(cell.getColumnIndex() > 6){
                    break;
                }
                rowValues[cell.getColumnIndex()] = getCellValue(cell);                                
            }
            
            String numRoom = rowValues[0];
            String name = rowValues[1];
            String lastName = rowValues[2];
            String email = rowValues[3];
            String gender = rowValues[4];
            String phone = rowValues[5];
            String dateIn = rowValues[6];
            
            State newState = new State(numRoom, phone, name, lastName, email, gender, dateIn);
            
            if(numRoom == null){
                stateTable.insert(newState);
            } 
            else{
                if(!numRoom.equals("num_hab")){
                    stateTable.insert(newState);                            
                }                
            }
        }
        
        return stateTable;
    }  
    
    
    /**
     * Obtiene un hashTable con los datos de la hoja de Reservas
     * @return 
     */
    public static HashTable getBooking(){
        HashTable bookingTable = new HashTable(500);
        
        Sheet sheet = getExcelSheet(BOOKING);        
        
        for(Row row: sheet){
            String[] rowValues = new String[9];
            
            for(Cell cell: row){
                if(cell.getColumnIndex() > 8){
                    break;
                }
                rowValues[cell.getColumnIndex()] = getCellValue(cell);                                
            }
            
            String id = rowValues[0];
            String name = rowValues[1];
            String lastName = rowValues[2];
            String email = rowValues[3];
            String gender = rowValues[4];
            String roomType = rowValues[5];
            String phone = rowValues[6];
            String dateIn = rowValues[7];
            String dateOut = rowValues[8];
            
            if(!id.equals("ci")){
                Booking newBooking = new Booking(id, roomType, phone, dateOut, name, lastName, email, gender, dateIn);
                bookingTable.insert(newBooking);                            
            }
        }
        
        return bookingTable;
    }
    
    
    /**
     * Obtiene un hashTable con los datos de la hoja de habitaciones
     * @return 
     */
    public static HashTable getRoom(){
        HashTable roomTable = new HashTable(500);
        
        Sheet sheet = getExcelSheet(ROOM);        
        
        for(Row row: sheet){
            String[] rowValues = new String[3];
            
            for(Cell cell: row){
                rowValues[cell.getColumnIndex()] = getCellValue(cell);                                
            }
            
            String numRoom = rowValues[0];
            String typeRoom = rowValues[1];
            String floor = rowValues[2];
            
            if(!numRoom.equals("num_hab")){
                Room newRoom = new Room(numRoom, typeRoom, floor);
                roomTable.insert(newRoom);                            
            }
        }
        
        return roomTable;
    }
    
    
    /**
     * Obtiene un hashTable con los datos de la hoja de historico
     * @return 
     */
    public static HashTable getRecord(){
        HashTable recordTable = new HashTable(1500);
        
        Sheet sheet = getExcelSheet(RECORD);        
        
        for(Row row: sheet){
            String[] rowValues = new String[7];
            
            for(Cell cell: row){
                rowValues[cell.getColumnIndex()] = getCellValue(cell);                                
            }
            
            String id = rowValues[0];
            String name = rowValues[1];
            String lastName = rowValues[2];
            String email = rowValues[3];
            String gender = rowValues[4];
            String dateIn = rowValues[5];
            String numRoom = rowValues[6];
                        
            if(!id.equals("ci")){
                Record newRecord = new Record(name, lastName, email, gender, dateIn, id, numRoom);
                recordTable.insert(newRecord);                            
            }
        }
        
        return recordTable;
    }
    
    
    
    public static Bst getBookingBst(){
        Bst bookingBst = new Bst();
        
        Sheet sheet = getExcelSheet(BOOKING);        
        
        for(Row row: sheet){
            String[] rowValues = new String[9];
            
            for(Cell cell: row){  
                if(cell.getColumnIndex() > 8){
                    break;
                }
                rowValues[cell.getColumnIndex()] = getCellValue(cell);                                
            }            
            
            String id = rowValues[0];
            String name = rowValues[1];
            String lastName = rowValues[2];
            String email = rowValues[3];
            String gender = rowValues[4];
            String roomType = rowValues[5];
            String phone = rowValues[6];
            String dateIn = rowValues[7];
            String dateOut = rowValues[8];
            
            if(!id.equals("ci")){
                Booking newBooking = new Booking(id, roomType, phone, dateOut, name, lastName, email, gender, dateIn);
                bookingBst.insertBooking(bookingBst.getRoot(), newBooking);
            }
        }
        
        return bookingBst; 
   }
    
    
    public static Bst getRecordBst(){
        Bst recordBst = new Bst();
        
        Sheet sheet = getExcelSheet(RECORD);        
        
        for(Row row: sheet){
            String[] rowValues = new String[7];
            
            for(Cell cell: row){  
                if(cell.getColumnIndex() > 6){
                    break;
                }
                rowValues[cell.getColumnIndex()] = getCellValue(cell);                                
            }            
            
            String id = rowValues[0];
            String name = rowValues[1];
            String lastName = rowValues[2];
            String email = rowValues[3];
            String gender = rowValues[4];
            String dateIn = rowValues[5];
            String numRoom = rowValues[6];
                        
            if(!id.equals("ci")){
                Record newRecord = new Record(name, lastName, email, gender, dateIn, id, numRoom);
                recordBst.insertRecord(recordBst.getRoot(), newRecord);                            
            }
        }
        
        return recordBst; 
   }
  
    
       

}
