/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package main;

import Classes.Booking;
import Classes.ExcelReader;
import Classes.Record;
import Classes.Room;
import Classes.State;
import EDD.Bst;
import EDD.HashTable;
import EDD.List;
import EDD.NodeBst;
import Interfaces.MainMenu;
import org.apache.poi.ss.usermodel.Cell;

/**
 *
 * @author Juan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new MainMenu().setVisible(true);

    
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        
       
        
    
        
        
    }
    
}
